<html>
<head>
<meta charset="utf-8"><script src="js/popper.min.js" ></script> 
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/cozunurlukAyarlari.css" />
<link rel="stylesheet" type="text/css" href="css/stillerim.css">
<script src="js/jquery-3.3.1.min.js" ></script> 
<script src="js/bootstrap.min.js" ></script>
<style type="text/css">
	
	}
</style>
</head>
<body style="background-color: #e8e8e8">
	<div class="container-fluid">
		<div class="row" style="background-color:#888781;">
			<div class="col-12">
				<div class="row">
					<div class="col-sm-4 col-md-2">
						<div class="row">
							<div class="col-12 logo">
								<img src="logo/logo.png" class="img-fluid ">
							</div>
						</div>
					</div>
					<div class="col-sm-8 col-md-5">
						<div class="row ">
							<div class="col-12 arama">
								<form class="d-flex">
							        <input class="form-control me-2" type="search" placeholder="Arama" aria-label="Search">
							        <button class="btn btn-outline-light" type="submit">Arama</button>
							      </form>
							  </div>
						</div>
					</div>
					<div class="col-sm-2 col-md-1">
						<div class="row">
							<div class="col-12 icon text-center hesap">
								<a href="" class="alink">Hesap Aç</a>
							</div>
						</div>
					</div>
					<div class="col-sm-2 col-md-1">
						<div class="row">
							<div class="col-12 icon text-center hesap">
								<a href="" class="alink">Giriş Yap</a>
							</div>
						</div>
					</div>
					<div class="col-sm-2 col-md-1">
						<div class="row">
							<div class="col-12 icon text-center">
								<a href="">
									<img src="icon/user.png" class="img-fluid">
								</a>
							</div>
						</div>
					</div>
					<div class="col-sm-2 col-md-1">
						<div class="row">
							<div class="col-12 icon text-center">
								<a href="">
									<img src="icon/notification.png" class="img-fluid">
								</a>

							</div>
						</div>
					</div>
					<div class="col-sm-2 col-md-1 pb-3">
						<div class="row">
							<div class="col-12 icon text-center">
								<a href="">
									<img src="icon/shopping-cart.png" class="img-fluid">
								</a>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<div class="row mt-4">
			<div class="col-12 text-center">
				<a href="">
				<img src="banner/banner.PNG" class="img-fluid">
			    </a>
			</div>
		</div>
	</div> 
<div class="container">
	<h3 class="mt-5">KATEGORİLER</h3>
	<div class="row p-1 mt-5">
				<div class="col-12" style="padding-left: 45px;">
				
		        </div>
		<div class="row">
		
			<div class="col-12 text-center justify-content-center kategoriler" >
				<div class="row mt-3 aling-self-center bosluk ">
					
					<div  class="col-sm-3 col-lg-2 ml-4 mr-2">
						<div class="row">
							<div  class="col-12 gorsel">
								<a class="link" href="">
									<img style="width: 68px; height: 68px;" src="resimler/kategoriler/oppo.jpg"/ class="img-fluid">
								</a>
							</div>
							<div class="col-12">
								<a class="ayar" style="text-decoration: none;"  href="">
							      Elektronik
							    </a>
							</div>
						</div>
					</div> 
					<div  class="col-sm-3 col-lg-2 ml-4 mr-2">
						<div class="row">
							<div class="col-12 gorsel">
								<a class="link" href="">
									<img src="resimler/kategoriler/resim22.PNG" class="img-fluid"/>
								</a>
							</div>
							<div class="col-12">
								<a class="ayar" style="text-decoration: none;"  href="">
							      Ev, Ofis
							    </a>
							</div>
						</div>
					</div>
					<div  class="col-sm-3 col-lg-2 ml-4 mr-2">
						<div class="row">
							<div class="col-12 gorsel">
								<a class="link" href="">
									<img src="resimler/kategoriler/resim3.PNG" class="img-fluid"/>
								</a>
							</div>
							<div class="col-12">
								<a class="ayar" style="text-decoration: none;"  href="">
							      Anne, Bebek
							    </a>
							</div>
						</div>
					</div>
					<div  class="col-sm-3 col-lg-2 ml-4 mr-2">
						<div class="row">
							<div class="col-12 gorsel">
								<a class="link" href="">
									<img src="resimler/kategoriler/resim4.PNG" class="img-fluid"/>
								</a>
							</div>
							<div class="col-12">
								<a class="ayar" style="text-decoration: none;"  href="">
							     Kozmetik
							    </a>
							</div>
						</div>
					</div>
					<div  class="col-sm-3 col-lg-2 ml-4 mr-2">
						<div class="row">
							<div class="col-12 gorsel">
								<a class="link" href="">
									<img src="resimler/kategoriler/resim5.PNG" class="img-fluid"/>
								</a>
							</div>
							<div class="col-12">
								<a class="ayar" style="text-decoration: none;"  href="">
							     Kozmetik
							    </a>
							</div>
						</div>
					</div>
					
					
					
				</div>
			</div> 
		</div> 
	</div>
		<div class="row text-center mt-4" >
			
			<div class="col-12 text-center">
				
				<img src="resimler/resim/resim1.PNG" class="img-fluid">

			</div>
			
		</div>
          <h3 class=" mt-5">FIRSAT ÜRÜNLER</h3>
		<div class="row">
        
			<?php  
			$db=new mysqli("localhost","root","","odev");
			$db->set_charset("utf8");
			$sorgu="SELECT * FROM icerikler";
			$sonuc=$db->query($sorgu);
			$ks=$sonuc->num_rows;
			for($i=0; $i<$ks; $i++){
				$kayit=$sonuc->fetch_assoc();
				$resim=$kayit["resim"];
				$urunAciklama=$kayit["urunAciklama"];
				$fiyat=$kayit["fiyat"];
			echo"<div class='col-sm-12 col-md-6 col-lg-4'>";
				echo"<div class='row text-center'>";
					echo"<div class='col-12'>";
						echo"<div class='urun cardurun text-center'>";  						
							  echo"<div class='urun-body'>";
							  	echo"<div class='col-12' style='font-size:20px; font-weight:bold;'>$urunAciklama</div>";
							  		echo"<div class='col-12 text-center'>";
											echo "<a href=''><img src='$resim' alt='' class='img-fluid'>";
					                         echo "</a>";
									echo"</div>";
								echo"</div>";

                               echo"<div class='row mt-2 justify-content-bottom'>";
								echo"<div class='col-6 fiyat'>$fiyat ₺</div>";
								echo"<div class='col-6 text-center'>"
								;
									echo"<a href='html.html'><button type='button' class='btn btn-light'>Sepete Ekle</button></a>";
								echo"</div>";

                                echo"</div>";
						echo"</div>";
					echo"</div>";
				echo"</div>";
			echo"</div>";
		}
			?>
			
		</div>
		</div>	
			
<section id="services">
  <div class="container">
  	<div class="row">
      <div class="col-sm-12 " style="padding-left: 45px;">
        <h1>POPÜLER MARKALAR</h1>
      </div>      
    </div>
	<div class="row text-center"> 
		<div class="col-md-6 col-lg-3 col-xs-12 ">
	        <div class="row p-3" >
	        	<div class="col-12 card">
	        		<div class="row">
	        			<div class="col-12 icon">
			            	<img src="resimler/markalar/resim1.PNG">
			            </div>
			           <div class="col-12 link">
			           		<a href="">Apple Cep Telefonu</a>
			          </div>	
			          <div class="col-12 link">
			           		<a href="">Apple Notebook</a>
			          </div>
			          <div class="col-12 link">
			           		<a href="">Apple Akıllı Saat</a>
			          </div>	           
			           	
	        		</div>
	        	</div>          
	        </div>
	      </div>
	      <div class="col-md-6 col-lg-3 col-xs-12  ">
	        <div class="row p-3" >
	        	<div class="col-12 card">
	        		<div class="row">
	        			 <div class="col-12 icon">
			            	<img src="resimler/markalar/resim2.PNG">
			            </div>
			           <div class="col-12 link">
			           		<a href="">Samsung Cep Telefonu</a>
			          </div>	
			          <div class="col-12 link">
			           		<a href="">Samsung Televizyon</a>
			          </div>
			          <div class="col-12 link">
			           		<a href="">Samsung Akıllı Saat</a>
			          </div>	
	        		</div>
	        	</div>         
	        </div>
	      </div>      
	      <div class="col-md-6 col-lg-3 col-xs-12">
	        <div class="row p-3" >
	        	<div class="col-12 card">
	        		<div class="row">
	        			<div class="col-12 icon">
			            	<img src="resimler/markalar/resim3.PNG">
			            </div>
			           <div class="col-12 link">
			           		<a href="">LG Cep Telefonu</a>
			          </div>	
			          <div class="col-12 link">
			           		<a href="">LG Televizyon</a>
			          </div>
			          <div class="col-12 link">
			           		<a href="">LG Klima</a>
			          </div>	
	        		</div>
	        	</div>          
	        </div>
	      </div>      
	      <div class="col-md-6  col-lg-3 col-xs-12 ">
	        <div class="row p-3" >
	        	<div class="col-12 card">
	        		<div class="row">
	        			<div class="col-12 icon">
			            	<img src="resimler/markalar/resim4.PNG">
			            </div>
			           <div class="col-12 link">
			           		<a href="">Philips Elektrikli Süpürge</a>
			          </div>	
			          <div class="col-12 link">
			           		<a href="">Philips Ütü</a>
			          </div>
			          <div class="col-12 link">
			           		<a href="">Philips Televizyon</a>
			          </div>	
	        		</div>
	        	</div>          
	        </div>
	      </div>
    </div>
    </div>
</section>


<div class="container" >
	<div style="border:1px solid  #879eab; margin-bottom: 30px;" class="row">
	<div class="col-12" >
		<div class="row">
			<div class="col-sm-6 col-lg-3">
				<div class="row p-3">
					<div class="col-5">
						<img src="icon/box.png">
					</div>
					<div class="col-7">
						<h5>Bugün Teslim</h5>
						<p>Seçili ürünlerde hafta içi 00:00 - 11:00 arası verdiğiniz siparişlerde gün içerisinde sahip olma fırsatı</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="row p-3">
					<div class="col-5">
						<img src="icon/package.png">
					</div>
					<div class="col-7">
						<h5>Yarın Teslim</h5>
						<p style="text-align: justify;">Seçili ürünlerde hafta içi 11:00 - 00:00 arası verdiğiniz siparişlerde ertesi gün sahip olma fırsatı</p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-lg-3">
				<div class="row p-3">
					<div class="col-5">
						<img src="icon/truck.png">
					</div>
					<div class="col-7">
						<h5>Kargo Bedava</h5>
						<p>Seçili ürünlerde standart kargo bedava.</p>
					</div>
				</div>
			</div>
			
			<div class="col-sm-6 col-lg-3">
				<div class="row p-3">
					<div class="col-5">
						<img src="icon/support.png">
					</div>
					<div class="col-7">
						<h5>Telefonla Sipariş</h5>
						<p>000000000</p>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>
</div>
<div class="container-fluid">
	<div class="row" id="footer" style="background-color: #888781;">
	<div class="col-12 text-centers">
		<div class="row text-center">
			<div class="col-sm-12 col-md-1"></div>
			<div class="col-sm-12 col-md-2">
				<div class="row">
					<div class="col-12"><h5>visli.com</h5></div>
					<div class="col-12"><a href="">Satıcı Başvuru </a></div>
					<div class="col-12"><a href=""> İşlem Rehberi</a></div>
					<div class="col-12"><a href="">Satıcıya Yorum Yap </a></div>
					<div class="col-12"><a href=""> Akakçe Felsefesi</a></div>
					<div class="col-12"><a href="">Hakkımızda </a></div>
					<div class="col-12"><a href="">About Us</a></div>
					<div class="col-12"><a href="">İletişim</a></div>
				</div>
			</div>
			<div class="col-sm-12 col-md-2">
				<div class="row">
					<div class="col-12"><h5>Popüler Kategoriler</h5></div>
					<div class="col-12"><a href="">Telefon</a></div>
					<div class="col-12"><a href="">Televizyon</a></div>
					<div class="col-12"><a href="">Buzdolabı</a></div>
					<div class="col-12"><a href="">Klima</a></div>
					<div class="col-12"><a href="">Laptop & Notebook</a></div>
					<div class="col-12"><a href="">Elektrikli Süpürge</a></div>
				</div>
			</div>
			<div class="col-sm-12 col-md-2">
				<div class="row">
					<div class="col-12"><h5>Özel Sayfalar</h5></div>
					<div class="col-12"><a href="">Gerçek İndirimler</a></div>
					<div class="col-12"><a href="">6 Ayın En Ucuz Fiyatlı Ürünleri</a></div>
					<div class="col-12"><a href="">Adetli Al Az Öde</a></div>
					<div class="col-12"><a href="">11.11 İndirimi</a></div>
					<div class="col-12"><a href="">Black Friday</a></div>					
					<div class="col-12"><a href="">Yılbaşı Hediyeleri</a></div>
					<div class="col-12"><a href="">Sevgililer Günü Hediyeleri</a></div>
					<div class="col-12"><a href="">Anneler Günü Hediyeleri</a></div>
				</div>
			</div>
			<div class="col-sm-12 col-md-2">
				<div class="row">
					<div class="col-12"><h5>Popüler Aramalar</h5></div>
					<div class="col-12"><a href="">Oppo Reno 3</a></div>
					<div class="col-12"><a href="">Xiaomi Redmi Note 8</a></div>
					<div class="col-12"><a href="">iPhone SE 2 2020</a></div>
					<div class="col-12"><a href="">Xiaomi Mi Band 5</a></div>
					<div class="col-12"><a href="">Xiaomi Redmi Note 9 Pro</a></div>
				</div>
			</div>

			<div class="col-sm-12 col-md-2">
				<div class="row">
					<div class="col-12"><h5>İndirimler</h5></div>
					<div class="col-12"><a href="">Hepsiburada İndirim</a></div>
					<div class="col-12"><a href="">Trendyol İndirim</a></div>
					<div class="col-12"><a href="">n11 İndirim</a></div>
					<div class="col-12"><a href="">Gittigidiyor Kampanya</a></div>
					<div class="col-12"><a href="">Teknosa İndirim</a></div>					
					<div class="col-12"><a href="">Media Markt Lampanyaları</a></div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

	
</body>
</html>
